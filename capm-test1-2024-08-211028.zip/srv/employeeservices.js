//const cds = require('@sap/cds');

module.exports = cds.service.impl(async function () {

    // Step 1: Get the object of our OData entities
    const { EmployeeSet } = this.entities; // Ensure 'EmployeeSet' matches the name of your entity

    // Step 2: Define 'before' event handlers for CREATE, UPDATE, and DELETE operations

    // Before CREATE operation
    this.before('CREATE', EmployeeSet, (req) => {
        // Retrieve salaryAmount and currencyCode from the request data
        var salary = parseInt(req.data.salaryAmount);
        var currencyCode = req.data.currencyCode;

        // Validation for salary and currency
        if (salary >= 50000 && currencyCode !== 'USD') {
            req.error(400, "Employee’s salary must be less than 50000 USD");
        } else {
            // If validation passes, allow the creation to proceed
            console.log('Create operation successful');
        }
    });

    // Before UPDATE operation
    this.before('UPDATE', EmployeeSet, (req) => {


        // Check if nameFirst or loginName are being changed
        if (req.data.nameFirst !== undefined && req.data.nameFirst !== originalData.nameFirst) {
            req.error(400, "Operation not allowed: nameFirst cannot be changed");
        }
        if (req.data.loginName !== undefined && req.data.loginName !== originalData[0].loginName) {
            req.error(400, "Operation not allowed: loginName cannot be changed");
        }

        // If validation passes and no forbidden fields are changed
        console.log('Update operation successful');
    });

    // Before DELETE operation
    this.before('DELETE', EmployeeSet, async (req) => {

        let id=req.data.ID;
        const pastData = await SELECT.from(EmployeeSet).columns('nameFirst').where ({ID:id});
        console.log(pastData[0].nameFirst[0]);
        if(pastData[0].nameFirst[0] == 'S'){
            req.error('Operation Not Possible');
        }
    });

    this.on('DELETE' , EmployeeSet, (req) => {
        console.log("Delete operation successfull")
    })
});
